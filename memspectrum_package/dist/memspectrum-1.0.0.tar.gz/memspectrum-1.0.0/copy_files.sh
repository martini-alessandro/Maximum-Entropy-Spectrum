cp ../GenerateTimeSeries.py ./memspectrum
cp ../memspectrum.py  ./memspectrum
