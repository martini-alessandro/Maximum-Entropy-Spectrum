cp ../GenerateTimeSeries.py ./memspectrum
cp ../memspectrum.py  ./memspectrum/__init__.py
