cp ../GenerateTimeSeries.py ./memspectrum
cp ../memspectrum.py  ./memspectrum
rm -r ./memspectrum/__pycache__
